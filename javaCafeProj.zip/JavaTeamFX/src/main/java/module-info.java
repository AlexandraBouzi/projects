module lab.unipi.gui.JavaTeamFX {
    requires javafx.controls;
	requires javafx.base;
    opens lab.unipi.gui.JavaTeamFX;
    exports lab.unipi.gui.JavaTeamFX;
    
}
