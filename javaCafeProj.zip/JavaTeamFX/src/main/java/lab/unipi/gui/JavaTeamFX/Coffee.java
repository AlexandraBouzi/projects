package lab.unipi.gui.JavaTeamFX;

//SubClass Coffee inherits from SuperClass Drink
public class Coffee extends Drink {
	private String typeCoffee;
	private String sugarAmount;
	private String dose;

	// nine-argument constructor
	public Coffee(String drinkType , String additional, String typeCoffee, String sweetener, String sugarAmount, String dose, String syrup, String dairyType, String special) {
		super(drinkType, sweetener, syrup, dairyType, additional, special);
		this.typeCoffee=typeCoffee;
		this.sugarAmount=sugarAmount;
		this.dose=dose;

	}

	// set dose
	public void setDose(String dose) {
		this.dose = dose;
	}

	// return dose
	public String getDose() {
		return dose;
	}


	// set type of coffee
	public void setTypeCoffee(String typeCoffee) {
		this.typeCoffee = typeCoffee;
	}

	// return type of coffee
	public String getTypeCoffee() {
		return this.typeCoffee;
	}


	// set amount of sugar
	public void setSugarAmount(String sugarAmount) {
		this.sugarAmount = sugarAmount;
	}

	// return amount of sugar
	public String getSugarAmount() {
		return sugarAmount;
	}

}
