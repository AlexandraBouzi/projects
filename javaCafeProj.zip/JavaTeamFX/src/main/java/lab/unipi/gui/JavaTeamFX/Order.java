package lab.unipi.gui.JavaTeamFX;

//	Class Order implements PriceList
public class Order  implements PriceList{
	private String orderNum;
	private String date;
	private String hour;
	private String deliveryMethod;
	private String address;
	private String orderStatus;
	private String whatsOrdered;
	private Drink orderedType;
	private double price;
	
	// seven-argument constructor
	public Order (String orderNum, String date, String hour, String deliveryMethod, String address, String orderStatus, String whatsOrdered) {
	
		this.setOrderNum(orderNum);
		this.setDate(date);
		this.setHour(hour);
		this.setDeliveryMethod(deliveryMethod);
		this.setAddress(address);
		this.setOrderStatus(orderStatus);
		this.setWhatsOrdered(whatsOrdered);
	}
	
	// Setter / Getter for order
	public void setOrderNum(String orderNum) {
	    this.orderNum = orderNum ;
	} 

	public String getOrderNum() {
	    return this.orderNum;
	}


	// Setter / Getter for date
	public void setDate(String date) {
	    this.date = date ;
	} 
	
	public String getDate() {
	    return this.date;
	} 

	
	// Setter / Getter for hour
	public void setHour(String hour) {
	    this.hour = hour ;
	} 

	public String getHour() {
	    return this.hour;
	} 

	
	// Setter / Getter for delivery method
	public void setDeliveryMethod(String deliveryMethod) {
	    this.deliveryMethod = deliveryMethod ;
	} 

	public String getDeliveryMethod() {
	    return this.deliveryMethod;
	} 

	
	// Setter / Getter for address
	public void setAddress(String address) {
	    this.address = address ;
	}
	
	public String getAddress() {
	    return this.address;
	}

	
	// Setter / Getter for what's ordered
	public void setWhatsOrdered(String whatsOrdered) {
	    this.whatsOrdered = whatsOrdered ;
	}
	
	public String getWhatsOrdered() {
	    return this.whatsOrdered;
	}

	
	// Setter / Getter for order status
	public void setOrderStatus(String orderStatus) {
	    this.orderStatus = orderStatus ;
	}

	public String getOrderStatus() {
	    return this.orderStatus;
	}
	
	
	//  Setter / Getter for OrderedType
	public void setOrderedType(Drink orderedType) {
		this.orderedType = orderedType;
	}

	public Drink getOrderedType() {
		return this.orderedType;
	}

	
	// Getter method to access Drink Fields from Order Class
	public String getDairyType() {
		return this.orderedType.getDairyType();
	}
	
	public String getDrinkType() {
		return this.orderedType.getDrinkType();
	}
	
	public String getAdditional() {
		return this.orderedType.getAdditional();
	}
	
	public String getSweetener() {
		return this.orderedType.getSweetener();
	}
	
	public String getSyrup() {
		return this.orderedType.getSyrup();
	}
	
	public String getSpecial() {
		return this.orderedType.getSpecial();
	}
	
	// Setter / Getter CalculateTotalPrice
	public void setCalculateTotalPrice(double price) {
		this.price = price;
	}
	
	public double getCalculateTotalPrice() {
		return this.price;
	}
	
	

}

 