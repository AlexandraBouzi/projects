package lab.unipi.gui.JavaTeamFX;

public interface PriceList {
double getCalculateTotalPrice();

void setCalculateTotalPrice(double price);
}


