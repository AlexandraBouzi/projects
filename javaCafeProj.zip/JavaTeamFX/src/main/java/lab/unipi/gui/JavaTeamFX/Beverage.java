package lab.unipi.gui.JavaTeamFX;

//SubClass Beverage inherits from SuperClass Drink
public class Beverage extends Drink {
	private String typeBeverage;
	private String size;

	// eight-argument constructor
	public Beverage(String drinkType, String sweetener, String syrup, String dairyType,
			String additional, String special, String typeBeverage, String size) {
		super(drinkType, sweetener, syrup, dairyType, additional, special);
		this.typeBeverage=typeBeverage;
		this.size=size;

	}

	// set type of beverage
	public void setTypeBeverage(String typeBeverage) {
		this.typeBeverage = typeBeverage;
	}

	// return type of beverage
	public String getTypeBeverage() {
		return typeBeverage;
	}

	// set size
	public void setSize(String size) {
		this.size = size;
	}

	// return size
	public String getSize() {
		return size;
	}

}