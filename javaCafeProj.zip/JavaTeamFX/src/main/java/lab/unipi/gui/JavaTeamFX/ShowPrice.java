package lab.unipi.gui.JavaTeamFX;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;

public class ShowPrice extends SceneCreator implements EventHandler<MouseEvent> {

	// FlowPane
	FlowPane buttonFlowPane;

	//GridPane
	GridPane rootGridPane, inputFieldsPane;

	//Buttons
	Button backBtn;

	//Labels
	Label coffeeLbl, beverageLbl, doseLbl, sizeLbl, beverageSizeLbl, otherLbl;

	public ShowPrice (double width,double height) {

		super(width,height);

		//GridPane: root
		rootGridPane = new GridPane();
		// GridPane: Input Fields
		inputFieldsPane = new GridPane();

		// FlowPane
	    buttonFlowPane = new FlowPane();

	    // Labels
		coffeeLbl = new Label ( "PRICE LIST\n\nCoffee: 2,00€" );
		beverageLbl = new Label ("Beverage:3,00€");
		doseLbl = new Label ( "Coffee Dose:\nSingle:0€\nDouble:+0,30€" );
		beverageSizeLbl = new Label ( "Beverage Size:\nSmall:0€ \n Medium:+0,30€ \n Large:+0,60€" );
		otherLbl = new Label ( "Other:\nSyrup:+0,30€\nWhipped Cream:+0,30€" );
		backBtn = new Button ( "Go Back" );

		//  Customize buttonFlowPane (add buttons to FlowPane)
		backBtn.setOnMouseClicked(this);
		buttonFlowPane.setHgap(10);
		buttonFlowPane.getChildren().add(backBtn);
		buttonFlowPane.setAlignment(Pos.BOTTOM_CENTER);
		
		
		// Customize inputFieldsPane (add Labels to GridPane)
        inputFieldsPane.setAlignment(Pos.TOP_CENTER);
        inputFieldsPane.setVgap(10);
        inputFieldsPane.setHgap(10);

        inputFieldsPane.add(coffeeLbl,0,0);
        inputFieldsPane.add(beverageLbl, 0, 1);
        inputFieldsPane.add(doseLbl, 0, 2);
        inputFieldsPane.add(beverageSizeLbl, 0, 3);
        inputFieldsPane.add(otherLbl, 0, 4);

		rootGridPane.add(inputFieldsPane, 1, 0);
		rootGridPane.add(buttonFlowPane, 0, 1);
        rootGridPane.add(backBtn, 2, 5);

}
	
	@Override
	Scene createScene() {
		return new Scene(rootGridPane, width, height);
	}
	
	@Override
	public void handle(MouseEvent event) {
		// If back button is pressed go back to management scene
		if (event.getSource()==backBtn) {
			App.primaryStage.setTitle("Order Management");
			App.primaryStage.setScene(App.manageScene);
		}
		
	}
	
}
