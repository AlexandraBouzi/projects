package lab.unipi.gui.JavaTeamFX;

public class Drink {
	private String drinkType;
	private String additional;
	private String sweetener;
	private String syrup;
	private String dairyType;
	private String special;

	public Drink() {
    }

	// six-argument constructor
	Drink (String drinkType, String sweetener, String syrup, String dairyType, String additional, String special) {
		this.drinkType=drinkType;
		this.additional=additional;
		this.sweetener=sweetener;
		this.syrup=syrup;
		this.dairyType=dairyType;
		this.special=special;

	}

	// Setter / Getter DrinkType
	public String getDrinkType() {
		return drinkType;
	}

	public void setDrinkType(String drinkType) {
		this.drinkType = drinkType;
	}


	// Setter / Getter Additional
	public void setAdditional(String additional) {
		this.additional = additional;
	}

	public String getAdditional() {
		return this.additional;
	}


	// Setter / Getter Sweetener
	public void setSweetener(String sweetener) {
		this.sweetener = sweetener;
	}

	public String getSweetener() {
		return this.sweetener;
	}


	// Setter / Getter Syrup
	public String getSyrup() {
		return this.syrup;
	}

	public void setSyrup(String syrup) {
		this.syrup = syrup;
	}


	// Setter / Getter DairyType
	public void setDairyType(String dairyType) {
		this.dairyType = dairyType;
	}

	public String getDairyType() {
		return this.dairyType;
	}


	// Setter / Getter Special
	public void setSpecial(String special) {
		this.special = special;
	}

	public String getSpecial() {
		return this.special;
	}

}
