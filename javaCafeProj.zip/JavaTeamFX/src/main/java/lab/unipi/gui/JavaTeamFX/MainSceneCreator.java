package lab.unipi.gui.JavaTeamFX;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;

public class MainSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {
		// Flow Pane (root node)
		FlowPane rootFlowPane;
		// Main scene buttons
		Button mngBtn, srchBtn;
	
		public MainSceneCreator(double width, double height) {
			super(width, height);
			rootFlowPane = new FlowPane();
	    	mngBtn = new Button("Order Management");
	    	srchBtn = new Button("Search Order");
	    		    	
	    	// Attach handle event to Buttons
	    	mngBtn.setOnMouseClicked(this);
	    	srchBtn.setOnMouseClicked(this);
	    	
	    	// Set up Flow pane
	    	rootFlowPane.setHgap(10);
	    	rootFlowPane.setAlignment(Pos.CENTER);
	    	
	    	// Add manage and search buttons to rootFlowPane
	    	rootFlowPane.getChildren().add(mngBtn);
	    	rootFlowPane.getChildren().add(srchBtn);
	    				
		}
		
		@Override
		public void handle(MouseEvent event) {
			if(event.getSource() == mngBtn) {
				App.primaryStage.setScene(App.manageScene);
				App.primaryStage.setTitle("Order Management");
			}
			if(event.getSource() == srchBtn) {
				App.primaryStage.setScene(App.searchScene);
				App.primaryStage.setTitle("Search Order");
			}
		}

		@Override
		Scene createScene() {
			return new Scene(rootFlowPane, width, height);
		}
}
