package lab.unipi.gui.JavaTeamFX;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;

public class ManageSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {
    //	FlowPane
    FlowPane buttonFlowPane;

    //	Grid Panes
    GridPane rootGridPane, inputFieldsPane;

    // Scene buttons
    Button newDrinkBtn, updateDrinkBtn, deleteDrinkBtn, backBtn , viewPriceListBtn;

    //	ComboBox Beverage
    ComboBox<String> typeBeverageComboBox, sizeComboBox;

    //	ComboBox Order
    ComboBox<String> orderStatusComboBox, deliveryMethodComboBox, whatsOrderedComboBox;

    //	ComboBox Drink
    ComboBox<String> drinkTypeComboBox, additionalComboBox, sweetenerComboBox, syrupComboBox, dairyTypeComboBox;

    //	ComboBox Coffee
    ComboBox<String>  doseComboBox, typeCoffeeComboBox, sugarAmountComboBox;

    // Tableview
    TableView<Order> orderTableView;

    Label coffeeLbl, beverageLbl, drinkLbl, orderLbl;

    // Class Order Labels
    Label specialLbl, hourLbl, dateLbl, deliveryMethodLbl, orderNumLbl, addressLbl, orderStatusLbl, whatsOrderedLbl;

    //Class Drink Labels
    Label drinkTypeLbl, additionalLbl, sweetenerLbl, syrupLbl, dairyTypeLbl;

    //Class Coffee Labels
    Label typeCoffeeLbl, sugarAmountLbl, doseLbl;

   //Class Beverage Labels
    Label typeBeverageLbl, sizeLbl;

    // TextFields
    TextField specialField, hourField, dateField, addressField, orderNumField;
  
	public ManageSceneCreator(double width, double height) {

		super(width, height);

        //GridPane: root
        rootGridPane = new GridPane();

        //FlowPane
        buttonFlowPane = new FlowPane();

        //Labels
        drinkLbl = new Label( "Drink Info" );

        whatsOrderedLbl = new Label( "Drink Category:" );
        drinkTypeLbl = new Label( "Drink Type:" );
        additionalLbl = new Label( "Additional: " );
        sweetenerLbl = new Label( "Sweetener: " );
        syrupLbl = new Label( "Syrup: " );
        dairyTypeLbl = new Label( "Dairy Type:" );
        specialLbl = new Label( "Specific Instructions:" );   
        
        
        orderLbl = new Label( "\n\nOrder information" );
        
        orderNumLbl = new Label( "Order Number:" );
        dateLbl = new Label( "Date(ddMMyyyy):" );
        hourLbl = new Label( "Hour:" );
        deliveryMethodLbl = new Label( "Delivery Method:" );
        addressLbl = new Label( "Address:" );
        orderStatusLbl = new Label( "Order Status:" );
          
        
        coffeeLbl = new Label( "Coffee\n\n" );
        
        typeCoffeeLbl = new Label( "Type Coffee: " );
        sugarAmountLbl = new Label( "Sugar Amount: " );
        doseLbl = new Label( "Dose: " );


        beverageLbl = new Label( "Beverage\n\n" );

        typeBeverageLbl = new Label( "Type Beverage:" );
        sizeLbl = new Label( "Size of Beverage:" );


        // Drink Info ComboBox
        whatsOrderedComboBox = new ComboBox<>();
        whatsOrderedComboBox.getItems().addAll( "Coffee", "Beverage" );

        drinkTypeComboBox = new ComboBox<>();
        drinkTypeComboBox.getItems().addAll( "Hot", "Cold" );

        sweetenerComboBox = new ComboBox<>();
        sweetenerComboBox.getItems().addAll(
        		"None",
        		"White sugar",
        		"Brown sugar",
        		"Stevia",
        		"Saccharin"
        		);

        syrupComboBox = new ComboBox<>();
        syrupComboBox.getItems().addAll( "Strawberry", "Hazelnut", "Caramel", "Chocolate" );

        dairyTypeComboBox = new ComboBox<>();
        dairyTypeComboBox.getItems().addAll( "Whole milk", "Light milk", "Lactose free milk" );

        additionalComboBox = new ComboBox<>();
        additionalComboBox.getItems().addAll(
        		"None",
        		"Whipped Cream",
        		"Cinnamon",
        		"Chocolate"
        		);


        // Coffee ComboBox
        typeCoffeeComboBox = new ComboBox<>();
        typeCoffeeComboBox.getItems().addAll( "Instant", "French", "Cappuccino", "Espresso" );
        typeCoffeeComboBox.setDisable(true);
        
        doseComboBox = new ComboBox<>();
        doseComboBox.getItems().addAll( "Single", "Double" );
        doseComboBox.setDisable(true);
        
        sugarAmountComboBox = new ComboBox<>();
        sugarAmountComboBox.getItems().addAll(  "Plain black", "With a little sugar", "Medium", "Sweet" );
        sugarAmountComboBox.setDisable(true);
        
        
        // Beverage ComboBox
        typeBeverageComboBox = new ComboBox<>();
        typeBeverageComboBox.getItems().addAll( "Coffeeccino", "Chocolate" );
        typeBeverageComboBox.setDisable(true);
        
        sizeComboBox = new ComboBox<>();
        sizeComboBox.getItems().addAll( "Small -12oz", "Medium -16oz", "Large -18oz" );
        sizeComboBox.setDisable(true);
        
        
        // Delivery ComboBox
        deliveryMethodComboBox = new ComboBox<>();
        deliveryMethodComboBox.getItems().addAll( "Pickup from cafe", "Delivery" ); 
  
        
        // Order ComboBox
        orderStatusComboBox = new ComboBox<>();
        orderStatusComboBox.getItems().addAll(
        		"Registered",
        		"Processing",
        		"Ready for delivery",
        		"Ready for pickup",
        		"Getting delivered",
        		"Complete"
        		);

        
        // Fields
        addressField = new TextField();
        addressField.setDisable(true);
        hourField = new TextField();
        dateField = new TextField();
        orderNumField = new TextField();
        specialField = new TextField();

        //Buttons
        newDrinkBtn = new Button( "New Drink" );
        updateDrinkBtn = new Button( "Update" );
        deleteDrinkBtn = new Button( "Delete" );
        backBtn = new Button( "Go Back" );
        viewPriceListBtn=new Button( "View price list" );
        
        
        // GridPane: Input Fields
        inputFieldsPane = new GridPane();
        
        //TableView
        orderTableView = new TableView<>();
        orderTableView.setMaxWidth(800);
        
        //  Attach events
        backBtn.setOnMouseClicked(this);
        newDrinkBtn.setOnMouseClicked(this);
        updateDrinkBtn.setOnMouseClicked(this);
        deleteDrinkBtn.setOnMouseClicked(this);
        orderTableView.setOnMouseClicked(this);
        viewPriceListBtn.setOnMouseClicked(this);
        
        //  Customize buttonFlowPane (add buttons to FlowPane)
        buttonFlowPane.setHgap(10);
        buttonFlowPane.getChildren().add(newDrinkBtn);
        buttonFlowPane.getChildren().add(viewPriceListBtn);
        buttonFlowPane.getChildren().add(updateDrinkBtn);
        buttonFlowPane.getChildren().add(deleteDrinkBtn);
        buttonFlowPane.setAlignment(Pos.BOTTOM_CENTER);
		
        // Customize inputFieldsPane (add Labels and TextFields to GridPane)
        inputFieldsPane.setAlignment(Pos.TOP_RIGHT);
        inputFieldsPane.setVgap(10);
        inputFieldsPane.setHgap(10);
        
        inputFieldsPane.add(drinkLbl, 0, 0);
        inputFieldsPane.add(whatsOrderedLbl, 0, 1);
        inputFieldsPane.add(whatsOrderedComboBox, 1, 1);
        inputFieldsPane.add(drinkTypeLbl, 0, 2);
        inputFieldsPane.add(drinkTypeComboBox, 1, 2);
        inputFieldsPane.add(sweetenerLbl, 0, 3);
        inputFieldsPane.add(sweetenerComboBox, 1, 3 );
        inputFieldsPane.add(syrupLbl, 0, 4);
        inputFieldsPane.add(syrupComboBox, 1, 4);
        inputFieldsPane.add(dairyTypeLbl, 0, 5);
        inputFieldsPane.add(dairyTypeComboBox, 1, 5);
        inputFieldsPane.add(additionalLbl, 0, 6);
        inputFieldsPane.add(additionalComboBox, 1, 6); 
        inputFieldsPane.add(specialLbl, 0, 7);
        inputFieldsPane.add(specialField, 1, 7); 
        
        
        inputFieldsPane.add(coffeeLbl, 0, 8);        
        inputFieldsPane.add(typeCoffeeLbl, 0, 9);
        inputFieldsPane.add(typeCoffeeComboBox, 1, 9);
        inputFieldsPane.add(doseLbl, 0, 10);
        inputFieldsPane.add(doseComboBox, 1, 10);
        inputFieldsPane.add(sugarAmountLbl, 0, 11);
        inputFieldsPane.add(sugarAmountComboBox, 1, 11);
        
        
        inputFieldsPane.add(beverageLbl, 3, 0);
        inputFieldsPane.add(typeBeverageLbl, 3, 1);
        inputFieldsPane.add(typeBeverageComboBox, 4, 1);
        inputFieldsPane.add(sizeLbl, 3, 2);
        inputFieldsPane.add(sizeComboBox, 4, 2);
        
        
        inputFieldsPane.add(orderLbl, 3, 3);
        inputFieldsPane.add(deliveryMethodLbl, 3, 4);
        inputFieldsPane.add(deliveryMethodComboBox, 4, 4);
        inputFieldsPane.add(addressLbl, 3, 5);
        inputFieldsPane.add(addressField, 4, 5);
        inputFieldsPane.add(hourLbl, 3, 6);
        inputFieldsPane.add(hourField, 4, 6); 
        inputFieldsPane.add(dateLbl, 3, 7);
        inputFieldsPane.add(dateField, 4, 7);      
        inputFieldsPane.add(orderStatusLbl, 3, 9 );
        inputFieldsPane.add(orderStatusComboBox, 4, 9);
        
        rootGridPane.setVgap(10);
        rootGridPane.setHgap(10);
        rootGridPane.add(inputFieldsPane, 1, 0);
        rootGridPane.add(orderTableView, 0, 0);
        rootGridPane.add(buttonFlowPane, 0, 1);
        rootGridPane.add(backBtn, 1, 1);
        rootGridPane.add(viewPriceListBtn, 1, 2);

        // Disable combo box
        String deliveryCmp = "Delivery";
        String pickupCmp = "Pickup from cafe";
		
        deliveryMethodComboBox.valueProperty().addListener((e) -> {
        	
        	// If delivery method is "Delivery", don't disable the address combo box 
        	if (deliveryMethodComboBox.getValue().equals(deliveryCmp)) {
        		addressField.setDisable(false);
        	}
         
        	// If delivery method is "Pickup from cafe", disable the address combo box 
        	if (deliveryMethodComboBox.getValue().equals(pickupCmp)) {
        		addressField.setText(null);
        		addressField.setDisable(true);
	    	}
	        	
        });
        
        String coffeeCmp = "Coffee";
        String beverageCmp = "Beverage";
        String noneCmp = "None";
		
        whatsOrderedComboBox.valueProperty().addListener((e) -> {
        	
        	// If user chooses Coffee, disable the Beverage combo boxes and empty them
        	if ( whatsOrderedComboBox.getValue().equals(coffeeCmp)) {
        	 	
        	 	typeCoffeeComboBox.setDisable(false);
        	 	doseComboBox.setDisable(false);
        	 	
        	 	typeBeverageComboBox.setValue(null);
        	 	sizeComboBox.setValue(null);
        	 	
        	 	typeBeverageComboBox.setDisable(true);
        	 	sizeComboBox.setDisable(true); 
	        	 
        	 	sweetenerComboBox.valueProperty().addListener((o) -> {
                	
        	 		// If order doesn't have sweetener, then disable the sugar amount combo box
        	     	if (sweetenerComboBox.getValue().equals(noneCmp) ) {
        	        	 sugarAmountComboBox.setDisable(true);
        	        	 sugarAmountComboBox.setValue(null);
        	        	 
        	        }
        	        else {
        	        	 sugarAmountComboBox.setDisable(false);        	 
        	        }
                });
        	}
        	// If user chooses Beverage, disable the Coffee combo boxes and empty them
        	else if ( whatsOrderedComboBox.getValue().equals(beverageCmp) ) {
        		typeCoffeeComboBox.setDisable(true);
        		doseComboBox.setDisable(true);
        		sugarAmountComboBox.setDisable(true);
        	 
        		typeCoffeeComboBox.setValue(null);
        		doseComboBox.setValue(null);
        		sugarAmountComboBox.setValue(null);
        	 
        		typeBeverageComboBox.setDisable(false);
        		sizeComboBox.setDisable(false);
	        }
         
        });
            
        // Add columns from drink and order class to table view
        TableColumn<Order,String> orderNumColumn = new TableColumn<>( "Order Code" );
        orderNumColumn.setCellValueFactory(new PropertyValueFactory<>( "orderNum" ));
        orderTableView.getColumns().add(orderNumColumn);        
        
        TableColumn<Order,String> whatsOrderedColumn = new TableColumn<>( "Drink Category" );
        whatsOrderedColumn.setCellValueFactory(new PropertyValueFactory<>( "whatsOrdered" ));
        orderTableView.getColumns().add(whatsOrderedColumn);
        
        TableColumn<Order,String> dateColumn = new TableColumn<>( "Date" );
        dateColumn.setCellValueFactory(new PropertyValueFactory<>( "date" ));
        orderTableView.getColumns().add(dateColumn);
        
        TableColumn<Order,String> hourColumn = new TableColumn<>( "Hour" );
        hourColumn.setCellValueFactory(new PropertyValueFactory<>( "hour" ));
        orderTableView.getColumns().add(hourColumn);
        
        TableColumn<Order,String> deliveryMethodComboBox = new TableColumn<>( "Delivery Method" );
        deliveryMethodComboBox.setCellValueFactory(new PropertyValueFactory<>( "deliveryMethod" ));
        orderTableView.getColumns().add(deliveryMethodComboBox);
        
        TableColumn<Order,String> addressColumn = new TableColumn<>( "Address" );
        addressColumn.setCellValueFactory(new PropertyValueFactory<>( "address" ));
        orderTableView.getColumns().add(addressColumn);
        
        TableColumn<Order,String> orderStatusColumn = new TableColumn<>( "Order Status" );
        orderStatusColumn.setCellValueFactory(new PropertyValueFactory<>( "orderStatus" ));
        orderTableView.getColumns().add(orderStatusColumn);
        
        TableColumn<Order,String> priceColumn = new TableColumn<>( "Price" );
        priceColumn.setCellValueFactory(new PropertyValueFactory<>( "calculateTotalPrice" ));
        orderTableView.getColumns().add(priceColumn);
        
        TableColumn<Order, String> drinkTypeColumn = new TableColumn<>( "Drink Type" );
        drinkTypeColumn.setCellValueFactory(new PropertyValueFactory<>( "drinkType" ));
        orderTableView.getColumns().add(drinkTypeColumn);
        
        TableColumn<Order,String> sweetenerColumn = new TableColumn<>( "Sweetener" );
        sweetenerColumn.setCellValueFactory(new PropertyValueFactory<>( "sweetener" ));
        orderTableView.getColumns().add(sweetenerColumn);
        
        TableColumn<Order, String> syrupColumn = new TableColumn<>( "Syrup" );
        syrupColumn.setCellValueFactory(new PropertyValueFactory<>( "syrup" ));
        orderTableView.getColumns().add(syrupColumn);
        
        TableColumn<Order,String> dairyTypeColumn = new TableColumn<>( "Dairytype" );
        dairyTypeColumn.setCellValueFactory(new PropertyValueFactory<>( "dairyType" ));
        orderTableView.getColumns().add(dairyTypeColumn);
        
        TableColumn<Order, String> additionalColumn = new TableColumn<>( "Additional" );
        additionalColumn.setCellValueFactory(new PropertyValueFactory<>( "additional" ));
        orderTableView.getColumns().add(additionalColumn);
        
        TableColumn<Order,String> specialColumn = new TableColumn<>( "Specific instructions" );
        specialColumn.setCellValueFactory(new PropertyValueFactory<>( "special" ));
        orderTableView.getColumns().add(specialColumn);
      
        // pre-created orders
        createOrder( "Beverage", "27062022-1-Beverage", "27062022", "18:00", "Delivery", "Androutsou 27", "Registered", "Cold", "Whipped Cream", "Stevia", "Chocolate", "Light milk", "----", null, null, null, null, null );
        createOrder( "Coffee", "29062022-2-Coffee", "29062022", "10:00", "Pick from cafe", null, "Ready for delivery", "Hot", "Cinnamon", "White Sugar", null, "Brown Sugar", null, "Chocolate", "----", "Lactose free milk", null, null );
        createOrder( "Beverage", "01072022-3-Beverage", "01072022", "15:00", "Delivery", "Kreontos 93", "Ready for delivery", "Cold", "None", "Stevia", "Chocolate", "Light milk", "----", null, null, null, null, null );
        createOrder( "Coffee", "04072022-4-Coffee", "04072022", "20:00", "Pick from cafe", null, "Registered", "Hot", "None", "White Sugar", null, "White sugar", "Chocolate", "Strawberry", "-----", "Whole milk", null, null );
        tableSync();
	
	}
	
	@Override
	Scene createScene() {
            
		return new Scene(rootGridPane, width, height);

	}


	@Override
	public void handle(MouseEvent event) {
		
		// If back button is pressed go back to main scene
		if (event.getSource() == backBtn) {
			App.primaryStage.setTitle( "Java Cafe" );
			App.primaryStage.setScene(App.mainScene);
		}
	
		// If view price list button is pressed show price list
		if (event.getSource() == viewPriceListBtn) {
			App.primaryStage.setTitle( "Order Management" );
			App.primaryStage.setScene(App.showPriceScene);
		}
	
		// If new drink button is pressed, check if fields are null. If not make new order
		if (event.getSource() == newDrinkBtn) {
			String whatsOrdered = whatsOrderedComboBox.getValue();
			String beverageCmp = "Beverage";
			String coffeeCmp = "Coffee";

			// If order is coffee
			if (whatsOrdered.equals(coffeeCmp)) {
				
				String drinkType = drinkTypeComboBox.getValue();
	            String additional = additionalComboBox.getValue();
	            String sweetener = sweetenerComboBox.getValue();
	            String syrup = syrupComboBox.getValue();
	            String dairyType = dairyTypeComboBox.getValue();
	            String special = specialField.getText();
	         	String date = dateField.getText();
	         	String hour = hourField.getText();
	         	String deliveryMethod = deliveryMethodComboBox.getValue();
	         	String address = addressField.getText();
	         	String orderStatus = orderStatusComboBox.getValue();
				String dose = doseComboBox.getValue();
				String typeCoffee = typeCoffeeComboBox.getValue();
				String sugarAmount = sugarAmountComboBox.getValue();
				String typeBeverage = "------";
				String size = "-------";
				int x = counter();
                String orderNum = date + "-" + x + "-Coffee";
                
                // Check if a field or combo box is empty and show error message
                if ( drinkTypeComboBox.getValue() == null ) {
                	Alert alertDrinkType = new Alert(Alert.AlertType.ERROR);
                	alertDrinkType.setTitle( "Error in new order" );
                	alertDrinkType.setContentText( "All fields must be filled." );
                	alertDrinkType.show();
                }
                else if ( additionalComboBox.getValue() == null ) {
                	Alert alertAdditional= new Alert(Alert.AlertType.ERROR);
                    alertAdditional.setTitle( "Error in new order" );
                    alertAdditional.setContentText( "All fields must be filled." );
                    alertAdditional.show();
                }
                else if ( sweetenerComboBox.getValue() == null ) {
                	Alert alertSweetener= new Alert(Alert.AlertType.ERROR);
                    alertSweetener.setTitle( "Error in new order" );
                    alertSweetener.setContentText( "All fields must be filled." );
                    alertSweetener.show();
                }
                else if ( dairyTypeComboBox.getValue() == null ) {
                	Alert alertDairyType = new Alert(Alert.AlertType.ERROR);
                    alertDairyType.setTitle( "Error in new order" );
                    alertDairyType.setContentText( "All fields must be filled ." );
                    alertDairyType.show();
                }
                else if ( dateField.getText() == null ) {
                	Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle( "Error in new order" );
                    alert.setContentText( "All fields must be filled." );
                    alert.show();
                }
                else if ( hourField.getText() == null ) {
                	Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle( "Error in new order" );
                    alert.setContentText( "All fields must be filled." );
                    alert.show();
                }
                else if ( deliveryMethodComboBox.getValue() == null ) {
                	Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle( "Error in new order" );
                    alert.setContentText( "All fields must be filled." );
                    alert.show();
                
                }
                else if ( orderStatusComboBox.getValue() == null ) {
                	Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle( "Error in new order" );
                    alert.setContentText( "All fields must be filled." );
                    alert.show();
                }
                else if ( doseComboBox.getValue() == null ) {
                	Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle( "Error in new order" );
                    alert.setContentText( "All fields must be filled." );
                    alert.show();
                }
                else if ( typeCoffeeComboBox.getValue() == null ) {
                	Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle( "Error in new order" );
                    alert.setContentText( "All fields must be filled." );
                    alert.show();
                }
                else {
                	createOrder( whatsOrdered, orderNum, date, hour, deliveryMethod, address, orderStatus, drinkType, additional, 
							 sweetener, syrup, dairyType,  typeCoffee, dose, sugarAmount, typeBeverage, size, special);
				tableSync();
                }
				clearTextFields();
			}
	
			// If order is beverage
			if (whatsOrdered.equals(beverageCmp)) {
				String drinkType = drinkTypeComboBox.getValue();
	            String additional = additionalComboBox.getValue();
	            String sweetener = sweetenerComboBox.getValue();
	            String syrup = syrupComboBox.getValue();
	            String dairyType = dairyTypeComboBox.getValue();
	            String special = specialField.getText();
	         	String date = dateField.getText();
	         	String hour = hourField.getText();
	         	String deliveryMethod = deliveryMethodComboBox.getValue();
	         	String address = addressField.getText();
	         	String orderStatus = orderStatusComboBox.getValue();
				String typeBeverage = typeBeverageComboBox.getValue();
				String size = sizeComboBox.getValue();
				String dose = "-------";
				String typeCoffee = "------";
				String sugarAmount = "--------";
				int x = counter();
				String orderNum = date + "-" + x + "-Beverage";
                
				 // Check if a field or combo box is empty and show error message
				if ( drinkTypeComboBox.getValue() == null ) {
                    Alert alertDrinkType = new Alert(Alert.AlertType.ERROR);
                    alertDrinkType.setTitle("Error in new order");
                    alertDrinkType.setContentText("All fields must be filled.");
                    alertDrinkType.show();
                }
                else if ( additionalComboBox.getValue() == null ) {
                	Alert alertAdditional = new Alert(Alert.AlertType.ERROR);
                    alertAdditional.setTitle( "Error in new order" );
                    alertAdditional.setContentText( "All fields must be filled." );
                    alertAdditional.show();
                }
                else if ( sweetenerComboBox.getValue() == null ) {
                	Alert alertSweetener = new Alert(Alert.AlertType.ERROR);
                    alertSweetener.setTitle( "Error in new order" );
                    alertSweetener.setContentText( "All fields must be filled." );
                    alertSweetener.show();
                }
                else if ( dairyTypeComboBox.getValue() == null ) {
                	Alert alertDairyType = new Alert(Alert.AlertType.ERROR);
                    alertDairyType.setTitle( "Error in new order" );
                    alertDairyType.setContentText( "All fields must be filled." );
                    alertDairyType.show();
                }
                else if ( dateField.getText() == null ) {
                	Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle( "Error in new order" );
                    alert.setContentText( "All fields must be filled." );
                    alert.show();
                }
                else if ( hourField.getText() == null ) {
                	Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle( "Error in new order" );
                    alert.setContentText( "All fields must be filled." );
                    alert.show();
                }
                else if ( deliveryMethodComboBox.getValue() == null ) {
                	Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle( "Error in new order" );
                    alert.setContentText( "All fields must be filled." );
                    alert.show();
                }
                else if ( orderStatusComboBox.getValue() == null ) {
                	Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle( "Error in new order" );
                    alert.setContentText( "All fields must be filled." );
                    alert.show();
                }
                else if ( sizeComboBox.getValue() == null ) {
                	Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle( "Error in new order" );
                    alert.setContentText( "All fields must be filled." );
                    alert.show();
                }
                else if ( typeBeverageComboBox.getValue() == null ) {
                	Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle( "Error in new order" );
                    alert.setContentText( "All fields must be filled." );
                    alert.show();
                }
                else {
                	createOrder( whatsOrdered, orderNum, date, hour, deliveryMethod, address, orderStatus, drinkType, additional,
							 sweetener, syrup, dairyType,  typeCoffee, dose, sugarAmount, typeBeverage, size, special);
				tableSync();
                }
                clearTextFields();
			}
		
        }
		
		// Get values from fields, update Order, sync table and orderList, clearFields
		if (event.getSource() == updateDrinkBtn) {
        	String whatsOrdered = whatsOrderedComboBox.getValue();
            String drinkType = drinkTypeComboBox.getValue();
            String additional = additionalComboBox.getValue();
            String sweetener = sweetenerComboBox.getValue();
            String syrup = syrupComboBox.getValue();
            String dairyType = dairyTypeComboBox.getValue();
            String special = specialField.getText();
            String typeCoffee = typeCoffeeComboBox.getValue();
            String sugarAmount = sugarAmountComboBox.getValue();
            String dose = doseComboBox.getValue();
            String deliveryMethod = deliveryMethodComboBox.getValue();
            String address = addressField.getText();
            String orderStatus = orderStatusComboBox.getValue();           
            updateDrink(whatsOrdered, drinkType, additional, sweetener, syrup, dairyType, special, typeCoffee, sugarAmount, dose, deliveryMethod, address, orderStatus);
            tableSync();
            clearTextFields();
        }
		
		
        // Delete Order by name
        if (event.getSource() == deleteDrinkBtn) {
            deleteOrder(orderStatusComboBox.getValue());

            tableSync();
            clearTextFields();
        }
        
        
        // Get Selected Order from TableView, get the values from the selection and set them to the fields
        if (event.getSource() == orderTableView) {
            Order selectedOrder =  orderTableView.getSelectionModel().getSelectedItem();
            if (selectedOrder != null) {
 
            	orderStatusComboBox.setValue(selectedOrder.getOrderStatus());
            	deliveryMethodComboBox.setValue(selectedOrder.getDeliveryMethod());
            	whatsOrderedComboBox.setValue(selectedOrder.getWhatsOrdered());
            	hourField.setText(selectedOrder.getHour());
            	dateField.setText(selectedOrder.getDate());
            	addressField.setText(selectedOrder.getAddress());
            	
                drinkTypeComboBox.setValue(selectedOrder.getOrderedType().getDrinkType());
                additionalComboBox.setValue(selectedOrder.getOrderedType().getAdditional());
                sweetenerComboBox.setValue(selectedOrder.getOrderedType().getSweetener());
                syrupComboBox.setValue(selectedOrder.getOrderedType().getSyrup());
                dairyTypeComboBox.setValue(selectedOrder.getOrderedType().getDairyType());
                specialField.setText(selectedOrder.getOrderedType().getSpecial());
                
            }
        }
	}
	
	public void createOrder(String whatsOrdered, String orderNum, String date, String hour, String deliveryMethod, String address, String orderStatus, String drinkType, String additional, 
								String sweetener, String syrup, String dairyType,  String typeCoffee, String dose, String sugarAmount, String typeBeverage, String size,String special) {
		
		String beverageCmp = "Beverage";
        String coffeeCmp = "Coffee";
        
        
        if ( whatsOrdered.equals(beverageCmp) ) {
            Order order = new Order( orderNum, date, hour, deliveryMethod, address, orderStatus, whatsOrdered );
            order.setOrderedType( new Beverage( drinkType, sweetener, syrup, dairyType, additional, special, typeBeverage, size ) );
            double price = 3.0;
            if ( "Medium -16oz".equals(size) ) {
            	price = 3.30;
            }
            else if ( "Large -18oz".equals(size) ) {
            	price = 3.60;
            }
            else if ( syrup != null ) {
            	price = price + 0.30;
            }
            else if ( "Whipped Cream".equals(additional) ) {
            	price = price + 0.30;
            }
            
            order.setCalculateTotalPrice(price);
            Singleton.getInstance().addToArray(order);
        }
        else if ( whatsOrdered.equals(coffeeCmp) ) {
            Order order = new Order( orderNum, date, hour, deliveryMethod, address, orderStatus, whatsOrdered );
            order.setOrderedType( new Coffee( drinkType, additional, typeCoffee, sweetener, sugarAmount, dose, syrup, dairyType, special));
            double price = 2.0;
            if ( "Double".equals(dose) ) {
                price = price + 0.30;
            }
            else if ( syrup != null ) {
                price = price + 0.30;
            }
            else if ( "Whipped Cream".equals(additional) ) {
                price = price + 0.30;
            }
           
            order.setCalculateTotalPrice(price);
            Singleton.getInstance().addToArray(order);
        }
	}

	// Refresh the table
	public void tableSync() {
    	orderTableView.getItems().clear();
        orderTableView.getItems().addAll(Singleton.getInstance().getArray());
    	
    }
  
    public void updateDrink(String whatsOrdered, String drinkType, String additional, String sweetener, String syrup, String dairyType, String special, String typeCoffee, String sugarAmount, String dose, String deliveryMethod, String address, String orderStatus) {
    	Order selectedOrder =  orderTableView.getSelectionModel().getSelectedItem();
            if ( (selectedOrder.getOrderStatus().equals( "Registered" )) ) {
            	selectedOrder.getOrderedType().setDrinkType(drinkType); 
            	selectedOrder.getOrderedType().setAdditional(additional);        
            	selectedOrder.getOrderedType().setSweetener(sweetener);             
            	selectedOrder.getOrderedType().setSyrup(syrup);
            	selectedOrder.getOrderedType().setDairyType(dairyType);
            	selectedOrder.getOrderedType().setSpecial(special);
            	selectedOrder.setDeliveryMethod(deliveryMethod);
            	selectedOrder.setAddress(address);
            	selectedOrder.setOrderStatus(orderStatus);
            }
             else if( selectedOrder.getOrderStatus() != "Registered" ) {
            	 Alert alertUpdate= new Alert(Alert.AlertType.ERROR);
            	 alertUpdate.setTitle( "Impossible update" );
            	 alertUpdate.setContentText( "Only orders that their status is 'Registered' can be updated." );
            	 alertUpdate.show();
            }
        }
    
    
    // Find an Order by order Status and delete it from orderList
    public void deleteOrder(String orderStatus) {
    	Order selectedOrder =  orderTableView.getSelectionModel().getSelectedItem();
    	if ( selectedOrder.getOrderStatus().equals( "Registered" ) ) {
    		Singleton.getInstance().removeFromArray(selectedOrder);
    	}
    	else if(selectedOrder.getOrderStatus()!="Registered") {
            Alert alertDelete = new Alert(Alert.AlertType.ERROR);
            alertDelete.setTitle( "Impossible delete" );
            alertDelete.setContentText( "To delete an order, the status should be 'Registered'." );
            alertDelete.show();
        }
    }
    
    
    // set to empty strings to clear the textFields and empty ComboBox
    public void clearTextFields() {
    	deliveryMethodComboBox.setValue(null);
    	whatsOrderedComboBox.setValue(null);
    	typeBeverageComboBox.setValue(null);
    	orderStatusComboBox.setValue(null);
    	sugarAmountComboBox.setValue(null);
        additionalComboBox.setValue(null);
        additionalComboBox.setValue(null);
        typeCoffeeComboBox.setValue(null);
        dairyTypeComboBox.setValue(null);
        sweetenerComboBox.setValue(null);
        drinkTypeComboBox.setValue(null);
        syrupComboBox.setValue(null);
        sizeComboBox.setValue(null);
        doseComboBox.setValue(null);
        addressField.setText("");
        specialField.setText("");
        hourField.setText("");
        dateField.setText("");
    }
    
    public int counter(){
    	int i;
    	for ( i = 0; i < Singleton.getInstance().getArray().size(); i++) {
    		i = i + 1;
    	}
    	return i + 1;
    }
    
}