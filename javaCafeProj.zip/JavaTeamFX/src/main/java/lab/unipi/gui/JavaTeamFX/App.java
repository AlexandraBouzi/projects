package lab.unipi.gui.JavaTeamFX;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {
	// Stage
	static Stage primaryStage;
	// Scenes
	static Scene mainScene, manageScene, searchScene, showPriceScene;
	
	
    @Override
    public void start(Stage primaryStage) {
    	this.primaryStage = primaryStage;
    	
    	SceneCreator mainSceneCreator = new MainSceneCreator(600, 300);
        mainScene = mainSceneCreator.createScene();
        
        SceneCreator manageSceneCreator = new ManageSceneCreator(1400, 550);
        manageScene = manageSceneCreator.createScene();
        
        SceneCreator searchSceneCreator = new SearchSceneCreator(750, 500);
        searchScene = searchSceneCreator.createScene();
        
        SceneCreator showPriceCreator = new ShowPrice(700, 300);
        showPriceScene = showPriceCreator.createScene();
    	
    	primaryStage.setScene(mainScene);
    	primaryStage.setTitle("Java Cafe");
    	primaryStage.show();
    	
    }

    public static void main(String[] args) {
        launch();
    }
}