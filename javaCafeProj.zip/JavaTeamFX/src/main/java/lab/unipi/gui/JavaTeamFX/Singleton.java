package lab.unipi.gui.JavaTeamFX;

import java.util.ArrayList;

public class Singleton  {

    private static Singleton mInstance;
    private ArrayList<Order> list;

    public static Singleton getInstance() {
        if (mInstance == null)
        	mInstance = new Singleton();

        return mInstance;
    }

    private Singleton() {
    	list = new ArrayList<Order>();
    }

    // Retrieve array from anywhere
    public ArrayList<Order> getArray() {
    	return this.list;
    }

    // Add element to array
    public void addToArray(Order value) {
    	list.add(value);
    }

    // Remove element from Array
    public void removeFromArray(Order value) {
    	list.remove(value);
    }

}