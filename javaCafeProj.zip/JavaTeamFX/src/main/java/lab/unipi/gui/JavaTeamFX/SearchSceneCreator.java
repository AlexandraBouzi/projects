package lab.unipi.gui.JavaTeamFX;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;

public class SearchSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {

	// Flow Pane
	FlowPane buttonFlowPane;
	
	// Grid Panes
	GridPane rootGridPane, inputFieldsPane;
	
	// Scene buttons
	Button srchDrinkBtn, backBtn;
	
	// scene labels
	Label drinkTypeLbl, dateLbl, fromLbl, untilLbl, orderStatusLbl;
	
	//  scene TextFields
	TextField fromField, untilField;
	
	// TableView
	TableView<Order> orderTableView;
	
	// Combo Box
	ComboBox<String> whatsOrderedComboBox, orderStatusComboBox;
	
	public SearchSceneCreator(double width, double height) {
		super(width, height);
		
        //GridPane: root
        rootGridPane = new GridPane();
        
        //buttonFlowPane
        buttonFlowPane = new FlowPane();
        
        //Labels
        drinkTypeLbl = new Label( "Drink Type: " );
        dateLbl = new Label( "Date of Order: " );
        fromLbl = new Label( "From: " );
        untilLbl = new Label( "Until: " );
        orderStatusLbl  = new Label( "Order Status: " );
        
        // Fields
        fromField = new TextField();
        untilField = new TextField();
        
        // Combo Box
        whatsOrderedComboBox = new ComboBox<>();
        whatsOrderedComboBox.getItems().addAll( "Coffee", "Beverage" );
        
        orderStatusComboBox = new ComboBox<>();
        orderStatusComboBox.getItems().addAll( "Registered", "In process", "Ready to receive from store",
        						"Ready for delivery", "On the way", "Delivered" );
        
        // Buttons
        srchDrinkBtn = new Button( "Search Order" );
        backBtn = new Button( "Go Back" );
        
        // GridPane: Input Fields
        inputFieldsPane = new GridPane();
        
        // TableView
        orderTableView = new TableView<>();
	
        // Attach events
        backBtn.setOnMouseClicked(this);
        srchDrinkBtn.setOnMouseClicked(this);
        orderTableView.setOnMouseClicked(this);
        
        // Customize buttonFlowPane (add buttons to FlowPane)
        buttonFlowPane.setHgap(10);
        buttonFlowPane.getChildren().add(srchDrinkBtn);
        buttonFlowPane.setAlignment(Pos.BOTTOM_CENTER);
		
        // Customize inputFieldsPane (add Labels and TextFields to GridPane)
        inputFieldsPane.setAlignment(Pos.TOP_RIGHT);
        inputFieldsPane.setVgap(10);
        inputFieldsPane.setHgap(10);
        inputFieldsPane.add(drinkTypeLbl, 0, 0);
        inputFieldsPane.add(whatsOrderedComboBox, 1, 0);
        inputFieldsPane.add(dateLbl, 0, 1);
     
        inputFieldsPane.add(fromLbl, 0, 2);
        inputFieldsPane.add(fromField, 1, 2);
        inputFieldsPane.add(untilLbl, 0, 3);
        inputFieldsPane.add(untilField, 1, 3);
        inputFieldsPane.add(orderStatusLbl, 0, 4);
        inputFieldsPane.add(orderStatusComboBox, 1, 4);
        
        // Customize rootGridPane (add buttonFlowPane, inputFieldsPane, back button and TableView to the root GridPane)
        rootGridPane.setVgap(10);
        rootGridPane.setHgap(10);
        rootGridPane.add(inputFieldsPane, 1, 0);
        rootGridPane.add(orderTableView, 0, 0);
        rootGridPane.add(buttonFlowPane, 0, 1);
        rootGridPane.add(backBtn, 1, 1);
        
        // Customize orderTableView: Create Column, create Cell and set it to Column. Add Column to TableView
        TableColumn<Order, String> orderCodeColumn = new TableColumn<>( "Order Code" );
        orderCodeColumn.setCellValueFactory(new PropertyValueFactory<>( "orderNum" ));
        orderTableView.getColumns().add(orderCodeColumn);

        TableColumn<Order, String> dateColumn = new TableColumn<>( "Date of Order" );
        dateColumn.setCellValueFactory(new PropertyValueFactory<>( "date" ));
        orderTableView.getColumns().add(dateColumn);
      
        TableColumn<Order, String> whatsOrderedComboBox = new TableColumn<>( "Drink Type" );
        whatsOrderedComboBox.setCellValueFactory(new PropertyValueFactory<>( "whatsOrdered" ));
        orderTableView.getColumns().add(whatsOrderedComboBox);
        
        TableColumn<Order, String> orderStatusComboBox = new TableColumn<>( "Order Status" );
        orderStatusComboBox.setCellValueFactory(new PropertyValueFactory<>( "orderStatus" ));
        orderTableView.getColumns().add(orderStatusComboBox);
           
        tableSync();
	}
	
	@Override
	Scene createScene() {
		return new Scene(rootGridPane, width, height);
	}
	
	@Override
	public void handle(MouseEvent event) {
		
		//Go back to main scene
		if (event.getSource() == backBtn) {
			App.primaryStage.setTitle("Java Cafe");
			App.primaryStage.setScene(App.mainScene);
		}

		// Search Order By categories
		if (event.getSource() == srchDrinkBtn) {
            String whatsOrdered  = whatsOrderedComboBox.getValue(); 
            String orderStatus = orderStatusComboBox.getValue(); 
            String from = fromField.getText();
            String until = untilField.getText();
            
            SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy",Locale.ENGLISH);
            Singleton.getInstance().getArray();
            ArrayList<Order> list = new ArrayList<Order>();
            
            for ( Order order : Singleton.getInstance().getArray() ) {
                Date untilDate = null;
                Date orderDate = null;
                String test = order.getDate();
                Date fromDate = null;
                try {
                     orderDate = formatter.parse(test);
                     fromDate = formatter.parse(from);  
                     untilDate = formatter.parse(until);
                } catch (ParseException e) {
                    e.printStackTrace();
                } 
                if (orderStatus != null && !(order.getOrderStatus()==orderStatus)) {
                    continue;
                }
                
                if (whatsOrdered != null && !(order.getWhatsOrdered()==whatsOrdered)) {
                    continue;
                }
                
                if (untilDate != null &&  !orderDate.before(untilDate)) {
                    continue;
                }

                  if (fromDate != null &&  !orderDate.after(fromDate)) {
                    continue;
                }

               list.add(order);
                
            }
            ObservableList<Order>  searchOrders = FXCollections.observableArrayList(list);
            orderTableView.getItems().clear();
            orderTableView.getItems().addAll(searchOrders);
            clearTextFields();
            tableSync();
        }
	}
	
	// Refresh the table
    public void tableSync() {
    	orderTableView.getItems().clear();
        orderTableView.getItems().addAll(Singleton.getInstance().getArray());
    }
   
    //set to empty strings to clear the textFields
    public void clearTextFields() {
    	fromField.setText("");
        untilField.setText("");
        whatsOrderedComboBox.setValue(null);
        orderStatusComboBox.setValue(null);
        
    }

}
